<template>
    <div class="space-y-5">
        <h2 class="text-2xl font-bold text-primary">Changelog</h2>

        <div class="panel space-y-5">
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.0.0 - 01 January, 2024</p>
                <div class="space-y-2">
                    <ul class="list-disc pl-10">
                        <li>Initial Release</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
    definePageMeta({
        layout: 'app-layout',
    });
</script>
